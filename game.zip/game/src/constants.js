var gridSize = 16;
var width = gridSize*48;
var height = gridSize*32;
