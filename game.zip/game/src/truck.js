var Truck = function(conflux, game, x, y, group, facing, speed, startPaused){
  if(typeof group === 'undefined'){ group = game.world; }
  if(typeof speed === 'undefined') { speed = 3; }
  Phaser.Sprite.call(this, game, x, y, 'truck');
  game.physics.arcade.enable(this);
  group.add(this);
  this.mobType = "truck";
  this.conflux = conflux;
  this.animations.add('plain', [0]);
  this.animations.play('plain');

  this.cConstants = {
    groundSpeed: speed*gridSize,
    fallSpeed: 20*gridSize,
    animationPausedOffset: 1
  };

  this.cState = {
    paused: false,
    facing: facing
  }

  this.update = function(){
    if(this.cState.paused){
      this.body.velocity.x = 0;
      this.body.velocity.y = 0;
      this.body.gravity.y = 0;
    } else {
      this.body.velocity.x = this.cConstants.groundSpeed*this.cState.facing;
      this.body.gravity.y = 40*gridSize;

      if(this.body.velocity.y > this.cConstants.fallSpeed){
        this.body.velocity.y = this.cConstants.fallSpeed;
      }

      if(this.body.onFloor()){
        this.y = Math.ceil(this.y);
      }
    }
  };

  this.debugString = function(){
    return "[pos:"+Math.floor(this.x)+"/"+Math.floor(this.y)+"]";
  };

  this.setPause = function(pause){
    if(this.cState.paused != pause){
      if(pause){
        this.animations.frame = this.animations.frame + this.cConstants.animationPausedOffset;
      } else {
        this.animations.frame = this.animations.frame - this.cConstants.animationPausedOffset;
      }
      this.animations.paused = pause;
      this.cState.paused = pause;
    }
  };
  this.setPause(!!startPaused);
}

Truck.prototype = Object.create(Phaser.Sprite.prototype);
Truck.prototype.constructor = Truck;
